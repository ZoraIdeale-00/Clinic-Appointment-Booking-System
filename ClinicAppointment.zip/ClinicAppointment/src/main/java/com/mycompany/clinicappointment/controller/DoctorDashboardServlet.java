/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.clinicappointment.controller;

import com.mycompany.clinicappointment.dao.AppointmentDAO;
import com.mycompany.clinicappointment.model.Appointment;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/doctor/dashboard")
public class DoctorDashboardServlet extends HttpServlet {

    private final AppointmentDAO appointmentDAO = new AppointmentDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        Integer doctorId = (Integer) session.getAttribute("doctorId");

        try {
            List<Appointment> appointments = appointmentDAO.getByDoctorId(doctorId);
            req.setAttribute("appointments", appointments);
            req.getRequestDispatcher("/doctor/dashboard.jsp").forward(req, resp);
        } catch (SQLException e) {
            throw new ServletException("Error loading appointments", e);
        }
    }
}