/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.clinicappointment.controller;

import com.mycompany.clinicappointment.dao.AppointmentDAO;
import com.mycompany.clinicappointment.dao.BillingDAO;
import com.mycompany.clinicappointment.dao.DoctorDAO;
import com.mycompany.clinicappointment.model.Appointment;
import com.mycompany.clinicappointment.model.Billing;
import com.mycompany.clinicappointment.model.Doctor;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;

@WebServlet("/doctor/billing")
public class GenerateBillServlet extends HttpServlet {

    private final AppointmentDAO appointmentDAO = new AppointmentDAO();
    private final BillingDAO billingDAO = new BillingDAO();
    private final DoctorDAO doctorDAO = new DoctorDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        Integer doctorId = (Integer) session.getAttribute("doctorId");
        int appointmentId = Integer.parseInt(req.getParameter("appointmentId"));

        try {
            Appointment appt = appointmentDAO.getById(appointmentId);
            if (appt == null || appt.getDoctorId() != doctorId) {
                resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Not your appointment");
                return;
            }
            if (!"COMPLETED".equals(appt.getStatus())) {
                resp.sendRedirect(req.getContextPath() + "/doctor/dashboard");
                return;
            }

            Billing existing = billingDAO.getByAppointmentId(appointmentId);
            if (existing != null) {
                resp.sendRedirect(req.getContextPath() + "/billing/view?appointmentId=" + appointmentId);
                return;
            }

            Doctor doctor = doctorDAO.getById(doctorId);
            req.setAttribute("appointment", appt);
            req.setAttribute("consultationFee", doctor.getConsultationFee());
            req.getRequestDispatcher("/doctor/billing.jsp").forward(req, resp);

        } catch (SQLException e) {
            throw new ServletException("Error loading billing form", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        Integer doctorId = (Integer) session.getAttribute("doctorId");
        int appointmentId = Integer.parseInt(req.getParameter("appointmentId"));

        try {
            Appointment appt = appointmentDAO.getById(appointmentId);
            if (appt == null || appt.getDoctorId() != doctorId) {
                resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Not your appointment");
                return;
            }

            // Re-fetch the doctor's fee from the DB rather than trusting a hidden form field
            Doctor doctor = doctorDAO.getById(doctorId);
            BigDecimal consultationFee = doctor.getConsultationFee();
            BigDecimal medicineFee = parseFeeOrZero(req.getParameter("medicineFee"));
            BigDecimal otherFee = parseFeeOrZero(req.getParameter("otherFee"));

            Billing billing = new Billing(appointmentId, consultationFee, medicineFee, otherFee);
            billingDAO.insert(billing);

            resp.sendRedirect(req.getContextPath() + "/billing/view?appointmentId=" + appointmentId);

        } catch (SQLException e) {
            throw new ServletException("Error generating bill", e);
        }
    }

    private BigDecimal parseFeeOrZero(String value) {
        if (value == null || value.isBlank()) return BigDecimal.ZERO;
        return new BigDecimal(value);
    }
}