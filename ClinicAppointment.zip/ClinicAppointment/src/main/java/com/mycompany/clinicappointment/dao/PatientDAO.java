/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.clinicappointment.dao;

import com.mycompany.clinicappointment.model.Patient;
import com.mycompany.clinicappointment.util.DBConnection;
import java.sql.*;
import java.util.*;

public class PatientDAO {

    private static final String BASE_SELECT =
        "SELECT p.*, u.full_name FROM patients p JOIN users u ON p.user_id = u.user_id ";

    public List<Patient> getAll() throws SQLException {
        List<Patient> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(BASE_SELECT + "ORDER BY u.full_name");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    public Patient getByUserId(int userId) throws SQLException {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(BASE_SELECT + "WHERE p.user_id = ?")) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    public Patient getById(int patientId) throws SQLException {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(BASE_SELECT + "WHERE p.patient_id = ?")) {
            ps.setInt(1, patientId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    public void insert(Patient p) throws SQLException {
        String sql = "INSERT INTO patients (user_id, date_of_birth, gender, address) VALUES (?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, p.getUserId());
            ps.setDate(2, p.getDateOfBirth());
            ps.setString(3, p.getGender());
            ps.setString(4, p.getAddress());
            ps.executeUpdate();
        }
    }

    public void update(Patient p) throws SQLException {
        String sql = "UPDATE patients SET date_of_birth=?, gender=?, address=? WHERE patient_id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDate(1, p.getDateOfBirth());
            ps.setString(2, p.getGender());
            ps.setString(3, p.getAddress());
            ps.setInt(4, p.getPatientId());
            ps.executeUpdate();
        }
    }

    private Patient mapRow(ResultSet rs) throws SQLException {
        return new Patient(
            rs.getInt("patient_id"), rs.getInt("user_id"), rs.getString("full_name"),
            rs.getDate("date_of_birth"), rs.getString("gender"), rs.getString("address")
        );
    }
}
