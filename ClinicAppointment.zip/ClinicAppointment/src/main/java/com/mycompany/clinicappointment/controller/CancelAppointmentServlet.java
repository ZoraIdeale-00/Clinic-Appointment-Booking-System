/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.clinicappointment.controller;

import com.mycompany.clinicappointment.dao.AppointmentDAO;
import com.mycompany.clinicappointment.model.Appointment;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/patient/cancel")
public class CancelAppointmentServlet extends HttpServlet {

    private final AppointmentDAO appointmentDAO = new AppointmentDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        Integer patientId = (Integer) session.getAttribute("patientId");
        int appointmentId = Integer.parseInt(req.getParameter("id"));

        try {
            Appointment appt = appointmentDAO.getById(appointmentId);
            if (appt != null && appt.getPatientId() == patientId) {
                appointmentDAO.updateStatus(appointmentId, "CANCELLED");
            }
            resp.sendRedirect(req.getContextPath() + "/patient/dashboard");
        } catch (SQLException e) {
            throw new ServletException("Error cancelling appointment", e);
        }
    }
}