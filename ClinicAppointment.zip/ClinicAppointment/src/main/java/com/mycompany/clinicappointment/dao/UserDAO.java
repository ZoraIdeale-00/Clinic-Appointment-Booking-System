/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.clinicappointment.dao;

import com.mycompany.clinicappointment.model.User;
import com.mycompany.clinicappointment.util.DBConnection;
import java.sql.*;

public class UserDAO {

    public User findByUsername(String username) throws SQLException {
        String sql = "SELECT * FROM users WHERE username = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    public User findById(int userId) throws SQLException {
        String sql = "SELECT * FROM users WHERE user_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    public boolean usernameExists(String username) throws SQLException {
        return findByUsername(username) != null;
    }

    public boolean emailExists(String email) throws SQLException {
        String sql = "SELECT 1 FROM users WHERE email = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    // Returns the generated user_id
    public int insert(User u) throws SQLException {
        String sql = "INSERT INTO users (username, password_hash, role, full_name, email, phone) VALUES (?,?,?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, u.getUsername());
            ps.setString(2, u.getPasswordHash());
            ps.setString(3, u.getRole());
            ps.setString(4, u.getFullName());
            ps.setString(5, u.getEmail());
            ps.setString(6, u.getPhone());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) return keys.getInt(1);
            }
        }
        return -1;
    }
    
    public void update(User u) throws SQLException {
    String sql = "UPDATE users SET full_name=?, email=?, phone=? WHERE user_id=?";
    try (Connection con = DBConnection.getConnection();
         PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setString(1, u.getFullName());
        ps.setString(2, u.getEmail());
        ps.setString(3, u.getPhone());
        ps.setInt(4, u.getUserId());
        ps.executeUpdate();
    }
}

public void delete(int userId) throws SQLException {
    try (Connection con = DBConnection.getConnection();
         PreparedStatement ps = con.prepareStatement("DELETE FROM users WHERE user_id=?")) {
        ps.setInt(1, userId);
        ps.executeUpdate();
    }
}

    private User mapRow(ResultSet rs) throws SQLException {
        return new User(
            rs.getInt("user_id"), rs.getString("username"), rs.getString("password_hash"),
            rs.getString("role"), rs.getString("full_name"), rs.getString("email"), rs.getString("phone")
        );
    }
}