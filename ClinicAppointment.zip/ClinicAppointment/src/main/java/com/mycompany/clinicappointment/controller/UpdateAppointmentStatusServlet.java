/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.clinicappointment.controller;

import com.mycompany.clinicappointment.dao.AppointmentDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/doctor/updateStatus")
public class UpdateAppointmentStatusServlet extends HttpServlet {

    private final AppointmentDAO appointmentDAO = new AppointmentDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        int appointmentId = Integer.parseInt(req.getParameter("id"));
        String status = req.getParameter("status");

        try {
            appointmentDAO.updateStatus(appointmentId, status);
            resp.sendRedirect(req.getContextPath() + "/doctor/dashboard");
        } catch (SQLException e) {
            throw new ServletException("Error updating status", e);
        }
    }
}