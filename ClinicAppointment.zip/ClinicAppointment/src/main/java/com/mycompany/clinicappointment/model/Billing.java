/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.clinicappointment.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class Billing {
    private int billingId;
    private int appointmentId;
    private BigDecimal consultationFee;
    private BigDecimal medicineFee;
    private BigDecimal otherFee;
    private BigDecimal totalFee;
    private String paymentStatus;   // UNPAID, PAID
    private Timestamp billingDate;

    public Billing() {}

    public Billing(int appointmentId, BigDecimal consultationFee,
                    BigDecimal medicineFee, BigDecimal otherFee) {
        this.appointmentId = appointmentId;
        this.consultationFee = consultationFee;
        this.medicineFee = medicineFee;
        this.otherFee = otherFee;
        this.totalFee = calculateTotal();
        this.paymentStatus = "UNPAID";
    }

    // The "calculation" business logic lives here, not in the JSP
    public BigDecimal calculateTotal() {
        BigDecimal c = consultationFee != null ? consultationFee : BigDecimal.ZERO;
        BigDecimal m = medicineFee != null ? medicineFee : BigDecimal.ZERO;
        BigDecimal o = otherFee != null ? otherFee : BigDecimal.ZERO;
        return c.add(m).add(o);
    }

    // Display helper - formats as "RM 120.00"
    public String getFormattedTotal() {
        return "RM " + calculateTotal().setScale(2, java.math.RoundingMode.HALF_UP);
    }

    public int getBillingId() { return billingId; }
    public void setBillingId(int billingId) { this.billingId = billingId; }
    public int getAppointmentId() { return appointmentId; }
    public void setAppointmentId(int appointmentId) { this.appointmentId = appointmentId; }
    public BigDecimal getConsultationFee() { return consultationFee; }
    public void setConsultationFee(BigDecimal consultationFee) { this.consultationFee = consultationFee; }
    public BigDecimal getMedicineFee() { return medicineFee; }
    public void setMedicineFee(BigDecimal medicineFee) { this.medicineFee = medicineFee; }
    public BigDecimal getOtherFee() { return otherFee; }
    public void setOtherFee(BigDecimal otherFee) { this.otherFee = otherFee; }
    public BigDecimal getTotalFee() { return totalFee; }
    public void setTotalFee(BigDecimal totalFee) { this.totalFee = totalFee; }
    public String getPaymentStatus() { return paymentStatus; }
    public void setPaymentStatus(String paymentStatus) { this.paymentStatus = paymentStatus; }
    public Timestamp getBillingDate() { return billingDate; }
    public void setBillingDate(Timestamp billingDate) { this.billingDate = billingDate; }
}
