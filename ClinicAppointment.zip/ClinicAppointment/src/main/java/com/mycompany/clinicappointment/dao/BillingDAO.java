/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.clinicappointment.dao;

import com.mycompany.clinicappointment.model.Billing;
import com.mycompany.clinicappointment.util.DBConnection;
import java.sql.*;

public class BillingDAO {

    public int insert(Billing b) throws SQLException {
        String sql = "INSERT INTO billing (appointment_id, consultation_fee, medicine_fee, other_fee, total_fee, payment_status) VALUES (?,?,?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, b.getAppointmentId());
            ps.setBigDecimal(2, b.getConsultationFee());
            ps.setBigDecimal(3, b.getMedicineFee());
            ps.setBigDecimal(4, b.getOtherFee());
            ps.setBigDecimal(5, b.calculateTotal());
            ps.setString(6, b.getPaymentStatus());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) return keys.getInt(1);
            }
        }
        return -1;
    }

    public Billing getByAppointmentId(int appointmentId) throws SQLException {
        String sql = "SELECT * FROM billing WHERE appointment_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, appointmentId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    public void markPaid(int billingId) throws SQLException {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement("UPDATE billing SET payment_status='PAID' WHERE billing_id=?")) {
            ps.setInt(1, billingId);
            ps.executeUpdate();
        }
    }

    private Billing mapRow(ResultSet rs) throws SQLException {
        Billing b = new Billing(rs.getInt("appointment_id"), rs.getBigDecimal("consultation_fee"),
                                 rs.getBigDecimal("medicine_fee"), rs.getBigDecimal("other_fee"));
        b.setBillingId(rs.getInt("billing_id"));
        b.setTotalFee(rs.getBigDecimal("total_fee"));
        b.setPaymentStatus(rs.getString("payment_status"));
        b.setBillingDate(rs.getTimestamp("billing_date"));
        return b;
    }
}
