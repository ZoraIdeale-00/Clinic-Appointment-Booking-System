/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.clinicappointment.controller;

import com.mycompany.clinicappointment.dao.DoctorDAO;
import com.mycompany.clinicappointment.dao.UserDAO;
import com.mycompany.clinicappointment.model.Doctor;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/admin/doctors/delete")
public class DeleteDoctorServlet extends HttpServlet {

    private final DoctorDAO doctorDAO = new DoctorDAO();
    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        int doctorId = Integer.parseInt(req.getParameter("id"));
        try {
            Doctor doctor = doctorDAO.getById(doctorId);
            if (doctor != null) {
                userDAO.delete(doctor.getUserId()); // cascades to doctors table
            }
            resp.sendRedirect(req.getContextPath() + "/admin/doctors");
        } catch (SQLException e) {
            throw new ServletException("Error deleting doctor", e);
        }
    }
}