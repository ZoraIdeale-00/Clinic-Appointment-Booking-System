/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.clinicappointment.controller;

import com.mycompany.clinicappointment.dao.PatientDAO;
import com.mycompany.clinicappointment.dao.UserDAO;
import com.mycompany.clinicappointment.model.Patient;
import com.mycompany.clinicappointment.model.User;
import com.mycompany.clinicappointment.util.PasswordUtil;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    private final UserDAO userDAO = new UserDAO();
    private final PatientDAO patientDAO = new PatientDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher("register.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String confirmPassword = req.getParameter("confirmPassword");
        String fullName = req.getParameter("fullName");
        String email = req.getParameter("email");
        String phone = req.getParameter("phone");
        String dob = req.getParameter("dateOfBirth");
        String gender = req.getParameter("gender");
        String address = req.getParameter("address");

        try {
            if (username == null || username.isBlank() || password == null || password.length() < 6) {
                req.setAttribute("error", "Username is required and password must be at least 6 characters.");
                forwardToRegister(req, resp);
                return;
            }
            if (!password.equals(confirmPassword)) {
                req.setAttribute("error", "Passwords do not match.");
                forwardToRegister(req, resp);
                return;
            }
            if (userDAO.usernameExists(username)) {
                req.setAttribute("error", "Username already taken.");
                forwardToRegister(req, resp);
                return;
            }
            if (userDAO.emailExists(email)) {
                req.setAttribute("error", "An account with this email already exists.");
                forwardToRegister(req, resp);
                return;
            }

            User user = new User();
            user.setUsername(username);
            user.setPasswordHash(PasswordUtil.hash(password));
            user.setRole("PATIENT");
            user.setFullName(fullName);
            user.setEmail(email);
            user.setPhone(phone);

            int userId = userDAO.insert(user);

            Patient patient = new Patient();
            patient.setUserId(userId);
            patient.setDateOfBirth(dob != null && !dob.isBlank() ? Date.valueOf(dob) : null);
            patient.setGender(gender);
            patient.setAddress(address);
            patientDAO.insert(patient);

            req.setAttribute("success", "Account created! You can now log in.");
            req.getRequestDispatcher("login.jsp").forward(req, resp);

        } catch (SQLException e) {
            throw new ServletException("Database error during registration", e);
        }
    }

    private void forwardToRegister(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        RequestDispatcher rd = req.getRequestDispatcher("register.jsp");
        rd.forward(req, resp);
    }
}