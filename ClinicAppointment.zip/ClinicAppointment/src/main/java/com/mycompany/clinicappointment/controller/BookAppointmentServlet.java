/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.clinicappointment.controller;

import com.mycompany.clinicappointment.dao.AppointmentDAO;
import com.mycompany.clinicappointment.dao.DoctorDAO;
import com.mycompany.clinicappointment.model.Appointment;
import com.mycompany.clinicappointment.model.Doctor;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.util.List;

@WebServlet("/patient/book")
public class BookAppointmentServlet extends HttpServlet {

    private final DoctorDAO doctorDAO = new DoctorDAO();
    private final AppointmentDAO appointmentDAO = new AppointmentDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            List<Doctor> doctors = doctorDAO.getAll();
            req.setAttribute("doctors", doctors);
            req.getRequestDispatcher("/patient/book.jsp").forward(req, resp);
        } catch (SQLException e) {
            throw new ServletException("Error loading doctors", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        Integer patientId = (Integer) session.getAttribute("patientId");

        int doctorId = Integer.parseInt(req.getParameter("doctorId"));
        String date = req.getParameter("appointmentDate");
        String time = req.getParameter("appointmentTime");
        String reason = req.getParameter("reason");

        try {
            Appointment appt = new Appointment();
            appt.setPatientId(patientId);
            appt.setDoctorId(doctorId);
            appt.setAppointmentDate(Date.valueOf(date));
            appt.setAppointmentTime(Time.valueOf(time + ":00"));
            appt.setReason(reason);
            appt.setStatus("PENDING");

            appointmentDAO.insert(appt);

            resp.sendRedirect(req.getContextPath() + "/patient/dashboard");
        } catch (SQLException e) {
            throw new ServletException("Error booking appointment", e);
        }
    }
}