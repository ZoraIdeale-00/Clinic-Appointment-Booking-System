/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.clinicappointment.dao;

import com.mycompany.clinicappointment.model.Doctor;
import com.mycompany.clinicappointment.util.DBConnection;
import java.sql.*;
import java.util.*;

public class DoctorDAO {

    private static final String BASE_SELECT =
        "SELECT d.*, u.full_name FROM doctors d JOIN users u ON d.user_id = u.user_id ";

    public List<Doctor> getAll() throws SQLException {
        List<Doctor> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(BASE_SELECT + "ORDER BY u.full_name");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    public Doctor getById(int doctorId) throws SQLException {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(BASE_SELECT + "WHERE d.doctor_id = ?")) {
            ps.setInt(1, doctorId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    public List<Doctor> searchBySpecialization(String keyword) throws SQLException {
        List<Doctor> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(BASE_SELECT + "WHERE d.specialization LIKE ?")) {
            ps.setString(1, "%" + keyword + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        }
        return list;
    }

    public void insert(Doctor d) throws SQLException {
        String sql = "INSERT INTO doctors (user_id, specialization, consultation_fee, available_days) VALUES (?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, d.getUserId());
            ps.setString(2, d.getSpecialization());
            ps.setBigDecimal(3, d.getConsultationFee());
            ps.setString(4, d.getAvailableDays());
            ps.executeUpdate();
        }
    }

    public void update(Doctor d) throws SQLException {
        String sql = "UPDATE doctors SET specialization=?, consultation_fee=?, available_days=? WHERE doctor_id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, d.getSpecialization());
            ps.setBigDecimal(2, d.getConsultationFee());
            ps.setString(3, d.getAvailableDays());
            ps.setInt(4, d.getDoctorId());
            ps.executeUpdate();
        }
    }

    public void delete(int doctorId) throws SQLException {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement("DELETE FROM doctors WHERE doctor_id=?")) {
            ps.setInt(1, doctorId);
            ps.executeUpdate();
        }
    }

    private Doctor mapRow(ResultSet rs) throws SQLException {
        return new Doctor(
            rs.getInt("doctor_id"), rs.getInt("user_id"), rs.getString("full_name"),
            rs.getString("specialization"), rs.getBigDecimal("consultation_fee"), rs.getString("available_days")
        );
    }
}