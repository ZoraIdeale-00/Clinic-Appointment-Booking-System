/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.clinicappointment.model;

import java.math.BigDecimal;

public class Doctor {
    private int doctorId;
    private int userId;
    private String fullName;     // joined from users table for display
    private String specialization;
    private BigDecimal consultationFee;
    private String availableDays;

    public Doctor() {}

    public Doctor(int doctorId, int userId, String fullName, String specialization,
                  BigDecimal consultationFee, String availableDays) {
        this.doctorId = doctorId;
        this.userId = userId;
        this.fullName = fullName;
        this.specialization = specialization;
        this.consultationFee = consultationFee;
        this.availableDays = availableDays;
    }

    public int getDoctorId() { return doctorId; }
    public void setDoctorId(int doctorId) { this.doctorId = doctorId; }
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public String getSpecialization() { return specialization; }
    public void setSpecialization(String specialization) { this.specialization = specialization; }
    public BigDecimal getConsultationFee() { return consultationFee; }
    public void setConsultationFee(BigDecimal consultationFee) { this.consultationFee = consultationFee; }
    public String getAvailableDays() { return availableDays; }
    public void setAvailableDays(String availableDays) { this.availableDays = availableDays; }
}
