/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.clinicappointment.controller;

import com.mycompany.clinicappointment.dao.DoctorDAO;
import com.mycompany.clinicappointment.dao.UserDAO;
import com.mycompany.clinicappointment.model.Doctor;
import com.mycompany.clinicappointment.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;

@WebServlet("/admin/doctors/edit")
public class EditDoctorServlet extends HttpServlet {

    private final DoctorDAO doctorDAO = new DoctorDAO();
    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        int doctorId = Integer.parseInt(req.getParameter("id"));
        try {
            Doctor doctor = doctorDAO.getById(doctorId);
            User user = userDAO.findById(doctor.getUserId());
            req.setAttribute("mode", "edit");
            req.setAttribute("doctor", doctor);
            req.setAttribute("user", user);
            req.getRequestDispatcher("/admin/doctorForm.jsp").forward(req, resp);
        } catch (SQLException e) {
            throw new ServletException("Error loading doctor", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        int doctorId = Integer.parseInt(req.getParameter("doctorId"));
        int userId = Integer.parseInt(req.getParameter("userId"));

        try {
            User user = userDAO.findById(userId);
            user.setFullName(req.getParameter("fullName"));
            user.setEmail(req.getParameter("email"));
            user.setPhone(req.getParameter("phone"));
            userDAO.update(user);

            Doctor doctor = new Doctor();
            doctor.setDoctorId(doctorId);
            doctor.setSpecialization(req.getParameter("specialization"));
            doctor.setConsultationFee(new BigDecimal(req.getParameter("consultationFee")));
            doctor.setAvailableDays(req.getParameter("availableDays"));
            doctorDAO.update(doctor);

            resp.sendRedirect(req.getContextPath() + "/admin/doctors");

        } catch (SQLException e) {
            throw new ServletException("Error updating doctor", e);
        }
    }
}