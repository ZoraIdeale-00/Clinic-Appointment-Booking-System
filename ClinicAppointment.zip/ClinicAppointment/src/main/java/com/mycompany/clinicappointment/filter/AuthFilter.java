/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Filter.java to edit this template
 */
package com.mycompany.clinicappointment.filter;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebFilter("/*")
public class AuthFilter implements Filter {

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;
        String uri = request.getRequestURI();
        String contextPath = request.getContextPath();
        String path = uri.substring(contextPath.length()); // strip context path

        // Public paths - no login required
        if (path.equals("/") || path.startsWith("/login") || path.startsWith("/register")
                || path.startsWith("/css/") || path.startsWith("/js/") || path.startsWith("/index")) {
            chain.doFilter(req, res);
            return;
        }

        HttpSession session = request.getSession(false);
        boolean loggedIn = (session != null && session.getAttribute("role") != null);

        if (!loggedIn) {
            response.sendRedirect(contextPath + "/login");
            return;
        }

        String role = (String) session.getAttribute("role"); // ADMIN, DOCTOR, PATIENT

        if (path.startsWith("/admin") && !role.equals("ADMIN")) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Access denied");
            return;
        }
        if (path.startsWith("/doctor") && !role.equals("DOCTOR")) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Access denied");
            return;
        }
        if (path.startsWith("/patient") && !role.equals("PATIENT")) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Access denied");
            return;
        }

        chain.doFilter(req, res); // allowed through
    }
}