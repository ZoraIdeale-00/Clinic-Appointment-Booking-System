/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.clinicappointment.controller;

import com.mycompany.clinicappointment.dao.AppointmentDAO;
import com.mycompany.clinicappointment.dao.BillingDAO;
import com.mycompany.clinicappointment.model.Appointment;
import com.mycompany.clinicappointment.model.Billing;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/billing/markPaid")
public class MarkPaidServlet extends HttpServlet {

    private final AppointmentDAO appointmentDAO = new AppointmentDAO();
    private final BillingDAO billingDAO = new BillingDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        Integer patientId = (Integer) session.getAttribute("patientId");
        int appointmentId = Integer.parseInt(req.getParameter("appointmentId"));

        try {
            Appointment appt = appointmentDAO.getById(appointmentId);
            if (appt == null || appt.getPatientId() != patientId) {
                resp.sendError(HttpServletResponse.SC_FORBIDDEN);
                return;
            }

            Billing billing = billingDAO.getByAppointmentId(appointmentId);
            if (billing != null) {
                billingDAO.markPaid(billing.getBillingId());
            }

            resp.sendRedirect(req.getContextPath() + "/billing/view?appointmentId=" + appointmentId);

        } catch (SQLException e) {
            throw new ServletException("Error marking bill as paid", e);
        }
    }
}