/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.clinicappointment.controller;

import com.mycompany.clinicappointment.dao.DoctorDAO;
import com.mycompany.clinicappointment.dao.UserDAO;
import com.mycompany.clinicappointment.model.Doctor;
import com.mycompany.clinicappointment.model.User;
import com.mycompany.clinicappointment.util.PasswordUtil;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;

@WebServlet("/admin/doctors/add")
public class AddDoctorServlet extends HttpServlet {

    private final UserDAO userDAO = new UserDAO();
    private final DoctorDAO doctorDAO = new DoctorDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setAttribute("mode", "add");
        req.getRequestDispatcher("/admin/doctorForm.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String fullName = req.getParameter("fullName");
        String email = req.getParameter("email");
        String phone = req.getParameter("phone");
        String specialization = req.getParameter("specialization");
        String feeStr = req.getParameter("consultationFee");
        String availableDays = req.getParameter("availableDays");

        try {
            if (userDAO.usernameExists(username)) {
                req.setAttribute("error", "Username already taken.");
                req.setAttribute("mode", "add");
                req.getRequestDispatcher("/admin/doctorForm.jsp").forward(req, resp);
                return;
            }

            User user = new User();
            user.setUsername(username);
            user.setPasswordHash(PasswordUtil.hash(password));
            user.setRole("DOCTOR");
            user.setFullName(fullName);
            user.setEmail(email);
            user.setPhone(phone);
            int userId = userDAO.insert(user);

            Doctor doctor = new Doctor();
            doctor.setUserId(userId);
            doctor.setSpecialization(specialization);
            doctor.setConsultationFee(new BigDecimal(feeStr));
            doctor.setAvailableDays(availableDays);
            doctorDAO.insert(doctor);

            resp.sendRedirect(req.getContextPath() + "/admin/doctors");

        } catch (SQLException e) {
            throw new ServletException("Error adding doctor", e);
        }
    }
}