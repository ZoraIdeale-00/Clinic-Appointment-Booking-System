/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.clinicappointment.dao;

import com.mycompany.clinicappointment.model.Appointment;
import com.mycompany.clinicappointment.util.DBConnection;
import java.sql.*;
import java.util.*;

public class AppointmentDAO {

    private static final String BASE_SELECT =
        "SELECT a.*, up.full_name AS patient_name, ud.full_name AS doctor_name " +
        "FROM appointments a " +
        "JOIN patients p ON a.patient_id = p.patient_id JOIN users up ON p.user_id = up.user_id " +
        "JOIN doctors d ON a.doctor_id = d.doctor_id JOIN users ud ON d.user_id = ud.user_id ";

    public List<Appointment> getAll() throws SQLException {
        List<Appointment> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(BASE_SELECT + "ORDER BY a.appointment_date DESC, a.appointment_time DESC");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    public Appointment getById(int appointmentId) throws SQLException {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(BASE_SELECT + "WHERE a.appointment_id = ?")) {
            ps.setInt(1, appointmentId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    public List<Appointment> getByPatientId(int patientId) throws SQLException {
        List<Appointment> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(BASE_SELECT + "WHERE a.patient_id = ? ORDER BY a.appointment_date DESC")) {
            ps.setInt(1, patientId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        }
        return list;
    }
    
    public List<Appointment> getByDoctorId(int doctorId) throws SQLException {
    List<Appointment> list = new ArrayList<>();
    try (Connection con = DBConnection.getConnection();
         PreparedStatement ps = con.prepareStatement(BASE_SELECT + "WHERE a.doctor_id = ? ORDER BY a.appointment_date DESC")) {
        ps.setInt(1, doctorId);
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(mapRow(rs));
        }
    }
    return list;
}

    // Search by patient name, doctor name, or status - powers your Search requirement
    public List<Appointment> search(String keyword) throws SQLException {
        List<Appointment> list = new ArrayList<>();
        String sql = BASE_SELECT + "WHERE up.full_name LIKE ? OR ud.full_name LIKE ? OR a.status LIKE ? " +
                     "ORDER BY a.appointment_date DESC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            String like = "%" + keyword + "%";
            ps.setString(1, like);
            ps.setString(2, like);
            ps.setString(3, like);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        }
        return list;
    }

    public int insert(Appointment a) throws SQLException {
        String sql = "INSERT INTO appointments (patient_id, doctor_id, appointment_date, appointment_time, reason, status) VALUES (?,?,?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, a.getPatientId());
            ps.setInt(2, a.getDoctorId());
            ps.setDate(3, a.getAppointmentDate());
            ps.setTime(4, a.getAppointmentTime());
            ps.setString(5, a.getReason());
            ps.setString(6, a.getStatus() != null ? a.getStatus() : "PENDING");
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) return keys.getInt(1);
            }
        }
        return -1;
    }

    public void update(Appointment a) throws SQLException {
        String sql = "UPDATE appointments SET appointment_date=?, appointment_time=?, reason=?, status=? WHERE appointment_id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDate(1, a.getAppointmentDate());
            ps.setTime(2, a.getAppointmentTime());
            ps.setString(3, a.getReason());
            ps.setString(4, a.getStatus());
            ps.setInt(5, a.getAppointmentId());
            ps.executeUpdate();
        }
    }

    public void updateStatus(int appointmentId, String status) throws SQLException {
        String sql = "UPDATE appointments SET status=? WHERE appointment_id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, appointmentId);
            ps.executeUpdate();
        }
    }

    public void delete(int appointmentId) throws SQLException {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement("DELETE FROM appointments WHERE appointment_id=?")) {
            ps.setInt(1, appointmentId);
            ps.executeUpdate();
        }
    }

    private Appointment mapRow(ResultSet rs) throws SQLException {
        Appointment a = new Appointment(
            rs.getInt("appointment_id"), rs.getInt("patient_id"), rs.getInt("doctor_id"),
            rs.getDate("appointment_date"), rs.getTime("appointment_time"),
            rs.getString("reason"), rs.getString("status")
        );
        a.setPatientName(rs.getString("patient_name"));
        a.setDoctorName(rs.getString("doctor_name"));
        a.setCreatedAt(rs.getTimestamp("created_at"));
        return a;
    }
}
