/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.clinicappointment.controller;

import com.mycompany.clinicappointment.dao.AppointmentDAO;
import com.mycompany.clinicappointment.model.Appointment;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/admin/dashboard")
public class AdminDashboardServlet extends HttpServlet {

    private final AppointmentDAO appointmentDAO = new AppointmentDAO();

    @Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException {
    try {
        String keyword = req.getParameter("keyword");
        List<Appointment> appointments;
        if (keyword != null && !keyword.isBlank()) {
            appointments = appointmentDAO.search(keyword);
        } else {
            appointments = appointmentDAO.getAll();
        }
        req.setAttribute("appointments", appointments);
        req.setAttribute("keyword", keyword);
        req.getRequestDispatcher("/admin/dashboard.jsp").forward(req, resp);
    } catch (SQLException e) {
        throw new ServletException("Error loading appointments", e);
    }
}
}