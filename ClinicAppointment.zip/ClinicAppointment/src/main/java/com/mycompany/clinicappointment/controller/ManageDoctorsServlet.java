/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.clinicappointment.controller;

import com.mycompany.clinicappointment.dao.DoctorDAO;
import com.mycompany.clinicappointment.model.Doctor;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/admin/doctors")
public class ManageDoctorsServlet extends HttpServlet {

    private final DoctorDAO doctorDAO = new DoctorDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            List<Doctor> doctors = doctorDAO.getAll();
            req.setAttribute("doctors", doctors);
            req.getRequestDispatcher("/admin/doctors.jsp").forward(req, resp);
        } catch (SQLException e) {
            throw new ServletException("Error loading doctors", e);
        }
    }
}