/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.clinicappointment.controller;

import com.mycompany.clinicappointment.dao.DoctorDAO;
import com.mycompany.clinicappointment.dao.PatientDAO;
import com.mycompany.clinicappointment.dao.UserDAO;
import com.mycompany.clinicappointment.model.Doctor;
import com.mycompany.clinicappointment.model.Patient;
import com.mycompany.clinicappointment.model.User;
import com.mycompany.clinicappointment.util.PasswordUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private final UserDAO userDAO = new UserDAO();
    private final DoctorDAO doctorDAO = new DoctorDAO();
    private final PatientDAO patientDAO = new PatientDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher("login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String username = req.getParameter("username");
        String password = req.getParameter("password");

        try {
            User user = userDAO.findByUsername(username);

            if (user == null || !PasswordUtil.verify(password, user.getPasswordHash())) {
                req.setAttribute("error", "Invalid username or password.");
                req.getRequestDispatcher("login.jsp").forward(req, resp);
                return;
            }

            HttpSession session = req.getSession(true);
            session.setAttribute("userId", user.getUserId());
            session.setAttribute("username", user.getUsername());
            session.setAttribute("fullName", user.getFullName());
            session.setAttribute("role", user.getRole());

            String contextPath = req.getContextPath();
            
            switch (user.getRole()) {
    case "ADMIN":
        resp.sendRedirect(contextPath + "/admin/dashboard");
        break;
    case "DOCTOR":
        Doctor doctor = doctorDAO.getById(getDoctorIdForUser(user.getUserId()));
        session.setAttribute("doctorId", doctor != null ? doctor.getDoctorId() : null);
        resp.sendRedirect(contextPath + "/doctor/dashboard");
        break;
    case "PATIENT":
        Patient patient = patientDAO.getByUserId(user.getUserId());
        session.setAttribute("patientId", patient != null ? patient.getPatientId() : null);
        resp.sendRedirect(contextPath + "/patient/dashboard");
        break;
    default:
        resp.sendRedirect(contextPath + "/login");
}

        } catch (SQLException e) {
            throw new ServletException("Database error during login", e);
        }
    }

    // small helper since DoctorDAO looks up by doctor_id, not user_id directly
    private int getDoctorIdForUser(int userId) throws SQLException {
        for (Doctor d : doctorDAO.getAll()) {
            if (d.getUserId() == userId) return d.getDoctorId();
        }
        return -1;
    }
}