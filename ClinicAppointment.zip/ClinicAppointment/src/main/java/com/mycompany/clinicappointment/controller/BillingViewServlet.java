/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.clinicappointment.controller;

import com.mycompany.clinicappointment.dao.AppointmentDAO;
import com.mycompany.clinicappointment.dao.BillingDAO;
import com.mycompany.clinicappointment.model.Appointment;
import com.mycompany.clinicappointment.model.Billing;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/billing/view")
public class BillingViewServlet extends HttpServlet {

    private final AppointmentDAO appointmentDAO = new AppointmentDAO();
    private final BillingDAO billingDAO = new BillingDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        String role = (String) session.getAttribute("role");
        int appointmentId = Integer.parseInt(req.getParameter("appointmentId"));

        try {
            Appointment appt = appointmentDAO.getById(appointmentId);
            if (appt == null) {
                resp.sendError(HttpServletResponse.SC_NOT_FOUND);
                return;
            }

            // Ownership check - patients/doctors can only view their own bills
            if ("PATIENT".equals(role)) {
                Integer patientId = (Integer) session.getAttribute("patientId");
                if (appt.getPatientId() != patientId) {
                    resp.sendError(HttpServletResponse.SC_FORBIDDEN);
                    return;
                }
            } else if ("DOCTOR".equals(role)) {
                Integer doctorId = (Integer) session.getAttribute("doctorId");
                if (appt.getDoctorId() != doctorId) {
                    resp.sendError(HttpServletResponse.SC_FORBIDDEN);
                    return;
                }
            } // ADMIN can view any bill

            Billing billing = billingDAO.getByAppointmentId(appointmentId);
            if (billing == null) {
                req.setAttribute("message", "No bill has been generated for this appointment yet.");
            }

            req.setAttribute("appointment", appt);
            req.setAttribute("billing", billing);
            req.getRequestDispatcher("/billing/view.jsp").forward(req, resp);

        } catch (SQLException e) {
            throw new ServletException("Error loading bill", e);
        }
    }
}