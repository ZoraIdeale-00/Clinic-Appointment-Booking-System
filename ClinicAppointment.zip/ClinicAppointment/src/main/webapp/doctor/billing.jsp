<%-- 
    Document   : billing
    Created on : Sep 25, 2026, 9:17:20 AM
    Author     : ilham
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css"><head><link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css"><title>Invoice</title></head>
<title>Generate Bill</title></head>
<body>
    <h2>Generate Bill</h2>
    <p>Patient: ${appointment.patientName} | Date: ${appointment.appointmentDate}</p>

    <form method="post" action="${pageContext.request.contextPath}/doctor/billing?appointmentId=${appointment.appointmentId}">
        <label>Consultation Fee: RM ${consultationFee} (fixed by your profile)</label><br><br>
        <label>Medicine Fee (RM): <input type="number" step="0.01" min="0" name="medicineFee" value="0.00"></label><br><br>
        <label>Other Fee (RM): <input type="number" step="0.01" min="0" name="otherFee" value="0.00"></label><br><br>
        <button type="submit">Generate Bill</button>
    </form>
    <p><a href="${pageContext.request.contextPath}/doctor/dashboard">Back to Dashboard</a></p>
</body>
</html>
