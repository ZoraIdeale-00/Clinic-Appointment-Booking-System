<%-- 
    Document   : dashboard
    Created on : Sep 25, 2026, 8:39:53 AM
    Author     : ilham
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css"><head><link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css"><title>Invoice</title></head>
<title>Doctor Dashboard</title></head>
<body>
    <h2>Welcome, Dr. ${sessionScope.fullName}</h2>
    <p><a href="${pageContext.request.contextPath}/logout">Logout</a></p>

    <h3>My Appointments</h3>
    <table border="1" cellpadding="6">
        <tr><th>Date</th><th>Time</th><th>Patient</th><th>Reason</th><th>Status</th><th>Action</th></tr>
        <c:forEach var="a" items="${appointments}">
            <tr>
                <td>${a.appointmentDate}</td>
                <td>${a.appointmentTime}</td>
                <td>${a.patientName}</td>
                <td>${a.reason}</td>
                <td>${a.status}</td>
                <td>
                    <c:if test="${a.status == 'PENDING'}">
                        <a href="${pageContext.request.contextPath}/doctor/updateStatus?id=${a.appointmentId}&status=CONFIRMED">Confirm</a>
                    </c:if>
                    <c:if test="${a.status == 'CONFIRMED'}">
                        <a href="${pageContext.request.contextPath}/doctor/updateStatus?id=${a.appointmentId}&status=COMPLETED">Complete</a>
                    </c:if>
                    <c:if test="${a.status == 'COMPLETED'}">
                        <a href="${pageContext.request.contextPath}/doctor/billing?appointmentId=${a.appointmentId}">Bill</a>
                    </c:if>
                    <c:if test="${a.status == 'PENDING' || a.status == 'CONFIRMED'}">
                        | <a href="${pageContext.request.contextPath}/doctor/updateStatus?id=${a.appointmentId}&status=CANCELLED"
                             onclick="return confirm('Cancel this appointment?');">Cancel</a>
                    </c:if>
                </td>
            </tr>
        </c:forEach>
    </table>
</body>
</html>