<%-- 
    Document   : register
    Created on : Sep 25, 2026, 12:10:33 AM
    Author     : ilham
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css"><head><link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css"><title>Invoice</title></head>
<title>Register - Clinic Appointment</title></head>
<body>
    <h2>Patient Registration</h2>
    <% if (request.getAttribute("error") != null) { %>
        <p style="color:red;"><%= request.getAttribute("error") %></p>
    <% } %>
    <form method="post" action="register">
        <label>Full Name: <input type="text" name="fullName" required></label><br><br>
        <label>Username: <input type="text" name="username" required></label><br><br>
        <label>Password: <input type="password" name="password" required></label><br><br>
        <label>Confirm Password: <input type="password" name="confirmPassword" required></label><br><br>
        <label>Email: <input type="email" name="email" required></label><br><br>
        <label>Phone: <input type="text" name="phone"></label><br><br>
        <label>Date of Birth: <input type="date" name="dateOfBirth"></label><br><br>
        <label>Gender:
            <select name="gender">
                <option value="MALE">Male</option>
                <option value="FEMALE">Female</option>
                <option value="OTHER">Other</option>
            </select>
        </label><br><br>
        <label>Address: <input type="text" name="address"></label><br><br>
        <button type="submit">Register</button>
    </form>
    <p>Already have an account? <a href="login">Login here</a></p>
</body>
</html>
