<%-- 
    Document   : index
    Created on : Sep 25, 2026, 8:44:08 AM
    Author     : ilham
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css"><head><link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css"><title>Invoice</title></head>
<title>Clinic Appointment Booking System</title></head>
<body>
    <h1>Clinic Appointment Booking System</h1>
    <p>Book and manage clinic appointments online.</p>
    <p>
        <a href="${pageContext.request.contextPath}/login">Login</a> |
        <a href="${pageContext.request.contextPath}/register">Register</a>
    </p>
</body>
</html>
