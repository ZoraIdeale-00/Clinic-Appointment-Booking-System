/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/JavaScript.js to edit this template
 */
/* ==========================================================
   Clinic Appointment Booking System - UI effects only.
   Does not touch any form data, URLs or server logic.
   ========================================================== */
(function () {
    'use strict';

    /* ---- 1. Pick a colour theme from the URL (runs immediately, no flash) ---- */
    var path = location.pathname.toLowerCase();
    var root = document.documentElement;
    var theme = 'home';
    if (/\/patient\//.test(path))              theme = 'patient';
    else if (/\/doctor\//.test(path))          theme = 'doctor';
    else if (/\/admin\//.test(path))           theme = 'admin';
    else if (/\/billing\//.test(path))         theme = 'billing';
    else if (/\/(login|register)\/?$/.test(path)) theme = 'auth';

    var segments = path.replace(/\/+$/, '').split('/');
    root.setAttribute('data-theme', theme);
    root.setAttribute('data-page', theme + '-' + segments[segments.length - 1]);

    document.addEventListener('DOMContentLoaded', function () {

        /* Login vs register icon (both share the "auth" theme) */
        if (theme === 'auth') {
            root.setAttribute('data-page',
                document.querySelector('form[action="register"]') ? 'register' : 'login');
        }

        /* ---- 2. Wrap page content + add header/footer decoration ---- */
        var body = document.body;
        var main = document.createElement('main');
        main.className = 'page';
        while (body.firstChild) { main.appendChild(body.firstChild); }

        var roles = {
            patient: 'Patient Portal', doctor: 'Doctor Portal', admin: 'Admin Portal',
            billing: 'Billing', auth: 'Welcome', home: 'Welcome'
        };
        var header = document.createElement('header');
        header.className = 'app-header';
        header.innerHTML =
            '<div class="brand-mark">✚</div>' +
            '<div class="brand-title">Clinic Appointment Booking</div>' +
            '<div class="brand-role">' + roles[theme] + '</div>';

        var footer = document.createElement('footer');
        footer.className = 'app-footer';
        footer.textContent = 'Clinic Appointment Booking System · SWC4253';

        body.appendChild(header);
        body.appendChild(main);
        body.appendChild(footer);

        /* ---- 3. Status text -> coloured badges ---- */
        var badgeClass = {
            PENDING: 'pending', CONFIRMED: 'confirmed', COMPLETED: 'completed',
            CANCELLED: 'cancelled', PAID: 'paid', UNPAID: 'unpaid'
        };
        document.querySelectorAll('td').forEach(function (td) {
            var text = td.textContent.trim();
            if (badgeClass[text] && td.children.length === 0) {
                var span = document.createElement('span');
                span.className = 'badge badge-' + badgeClass[text];
                span.textContent = text;
                td.textContent = '';
                td.appendChild(span);
            }
        });

        /* ---- 4. Action links -> pill buttons (red for cancel/delete) ---- */
        document.querySelectorAll('td a, a[href*="markPaid"]').forEach(function (a) {
            a.classList.add('act');
            if (/cancel|delete/i.test(a.getAttribute('href') || '')) {
                a.classList.add('danger');
            }
        });
    });

    /* ---- 5. Click ripple on buttons and action links ---- */
    document.addEventListener('click', function (e) {
        var el = e.target.closest('button, a.act');
        if (!el) return;
        var rect = el.getBoundingClientRect();
        var size = Math.max(rect.width, rect.height);
        var x = e.detail === 0 ? rect.width / 2 : e.clientX - rect.left;   /* keyboard press = centre */
        var y = e.detail === 0 ? rect.height / 2 : e.clientY - rect.top;
        var ripple = document.createElement('span');
        ripple.className = 'ripple';
        ripple.style.width = ripple.style.height = size + 'px';
        ripple.style.left = (x - size / 2) + 'px';
        ripple.style.top = (y - size / 2) + 'px';
        el.appendChild(ripple);
        setTimeout(function () { ripple.remove(); }, 600);
    });

    /* ---- 6. Smooth fade-out before navigating to another page ---- */
    document.addEventListener('click', function (e) {
        /* e.defaultPrevented is true when the user pressed "Cancel" in a confirm() dialog */
        if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
        var a = e.target.closest('a[href]');
        if (!a) return;
        var href = a.getAttribute('href');
        if (!href || href.charAt(0) === '#' || /^(javascript|mailto|tel):/i.test(href) ||
            a.target === '_blank' || a.hasAttribute('download')) return;
        var url;
        try { url = new URL(a.href, location.href); } catch (err) { return; }
        if (url.origin !== location.origin) return;

        e.preventDefault();
        document.body.classList.add('leaving');
        setTimeout(function () { location.href = a.href; }, 220);
        setTimeout(function () { document.body.classList.remove('leaving'); }, 3000); /* safety net */
    });

    /* ---- 7. Spinner on submit buttons (form still submits normally) ---- */
    document.addEventListener('submit', function (e) {
        var btn = e.target.querySelector('button[type="submit"], button:not([type])');
        if (!btn) return;
        btn.classList.add('is-loading');
        setTimeout(function () { btn.classList.remove('is-loading'); }, 5000);
    });

    /* Back/forward button: make sure the page is visible again */
    window.addEventListener('pageshow', function (e) {
        if (e.persisted) document.body.classList.remove('leaving');
    });
})();