<%-- 
    Document   : view
    Created on : Sep 25, 2026, 9:17:43 AM
    Author     : ilham
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css"><title>Invoice</title></head>
<body>
    <h2>Invoice - Appointment #${appointment.appointmentId}</h2>
    <p>Patient: ${appointment.patientName} | Doctor: ${appointment.doctorName} | Date: ${appointment.appointmentDate}</p>

    <c:choose>
        <c:when test="${billing == null}">
            <p>${message}</p>
        </c:when>
        <c:otherwise>
            <table border="1" cellpadding="6">
                <tr><td>Consultation Fee</td><td>RM ${billing.consultationFee}</td></tr>
                <tr><td>Medicine Fee</td><td>RM ${billing.medicineFee}</td></tr>
                <tr><td>Other Fee</td><td>RM ${billing.otherFee}</td></tr>
                <tr><td><strong>Total</strong></td><td><strong>RM ${billing.totalFee}</strong></td></tr>
                <tr><td>Payment Status</td><td>${billing.paymentStatus}</td></tr>
            </table>

            <c:if test="${sessionScope.role == 'PATIENT' && billing.paymentStatus == 'UNPAID'}">
                <br>
                <a href="${pageContext.request.contextPath}/billing/markPaid?appointmentId=${appointment.appointmentId}"
                   onclick="return confirm('Confirm payment of RM ${billing.totalFee}?');">Mark as Paid</a>
            </c:if>
        </c:otherwise>
    </c:choose>

    <p><a href="${pageContext.request.contextPath}/${sessionScope.role == 'DOCTOR' ? 'doctor' : (sessionScope.role == 'ADMIN' ? 'admin' : 'patient')}/dashboard">Back to Dashboard</a></p>
</body>
</html>
