<%-- 
    Document   : book
    Created on : Sep 25, 2026, 8:39:27 AM
    Author     : ilham
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css"><head><link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css"><title>Invoice</title></head>
<title>Book Appointment</title></head>
<body>
    <h2>Book an Appointment</h2>
    <form method="post" action="${pageContext.request.contextPath}/patient/book">
        <label>Doctor:
            <select name="doctorId" required>
                <c:forEach var="d" items="${doctors}">
                    <option value="${d.doctorId}">${d.fullName} - ${d.specialization} (RM ${d.consultationFee})</option>
                </c:forEach>
            </select>
        </label><br><br>
        <label>Date: <input type="date" name="appointmentDate" required></label><br><br>
        <label>Time: <input type="time" name="appointmentTime" required></label><br><br>
        <label>Reason: <textarea name="reason"></textarea></label><br><br>
        <button type="submit">Book</button>
    </form>
    <p><a href="${pageContext.request.contextPath}/patient/dashboard">Back to Dashboard</a></p>
</body>
</html>