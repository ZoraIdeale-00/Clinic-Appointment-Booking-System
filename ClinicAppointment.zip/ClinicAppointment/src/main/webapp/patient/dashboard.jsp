<%-- 
    Document   : dashboard
    Created on : Sep 25, 2026, 8:38:56 AM
    Author     : ilham
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css"><head><link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css"><title>Invoice</title></head>
<title>Patient Dashboard</title></head>
<body>
    <h2>Welcome, ${sessionScope.fullName}</h2>
    <p><a href="${pageContext.request.contextPath}/patient/book">Book New Appointment</a> |
       <a href="${pageContext.request.contextPath}/logout">Logout</a></p>

    <h3>My Appointments</h3>
    <table border="1" cellpadding="6">
        <tr><th>Date</th><th>Time</th><th>Doctor</th><th>Reason</th><th>Status</th><th>Action</th></tr>
        <c:forEach var="a" items="${appointments}">
            <tr>
                <td>${a.appointmentDate}</td>
                <td>${a.appointmentTime}</td>
                <td>${a.doctorName}</td>
                <td>${a.reason}</td>
                <td>${a.status}</td>
                <td>
                    <c:if test="${a.status == 'COMPLETED'}">
                        <a href="${pageContext.request.contextPath}/billing/view?appointmentId=${a.appointmentId}">View Bill</a>
                    </c:if>
                    <c:if test="${a.status == 'PENDING' || a.status == 'CONFIRMED'}">
                        <a href="${pageContext.request.contextPath}/patient/cancel?id=${a.appointmentId}"
                           onclick="return confirm('Cancel this appointment?');">Cancel</a>
                    </c:if>
                </td>
            </tr>
        </c:forEach>
    </table>
</body>
</html>