<%-- 
    Document   : login
    Created on : Sep 25, 2026, 12:09:54 AM
    Author     : ilham
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css"><head><link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css"><title>Invoice</title></head>
<title>Login - Clinic Appointment</title></head>
<body>
    <h2>Login</h2>
    <% if (request.getAttribute("error") != null) { %>
        <p style="color:red;"><%= request.getAttribute("error") %></p>
    <% } %>
    <% if (request.getAttribute("success") != null) { %>
        <p style="color:green;"><%= request.getAttribute("success") %></p>
    <% } %>
    <form method="post" action="login">
        <label>Username: <input type="text" name="username" required></label><br><br>
        <label>Password: <input type="password" name="password" required></label><br><br>
        <button type="submit">Login</button>
    </form>
    <p>No account? <a href="register">Register here</a></p>
</body>
</html>
