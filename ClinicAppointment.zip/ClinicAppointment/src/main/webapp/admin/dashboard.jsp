<%-- 
    Document   : dashboard
    Created on : Sep 25, 2026, 8:40:21 AM
    Author     : ilham
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">   <script src="${pageContext.request.contextPath}/js/app.js"></script><title>Admin Dashboard</title></head>
<body>
    <h2>Admin Dashboard</h2>    
    <p><a href="${pageContext.request.contextPath}/logout">Logout</a></p>
    <a href="${pageContext.request.contextPath}/admin/doctors">Manage Doctors</a> |
    
    <form method="get" action="${pageContext.request.contextPath}/admin/dashboard">
    <input type="text" name="keyword" placeholder="Search by patient, doctor, or status"
           value="${keyword}">
    <button type="submit">Search</button>
    <a href="${pageContext.request.contextPath}/admin/dashboard">Clear</a>
</form>

    <h3>All Appointments</h3>
    <table border="1" cellpadding="6">
        <tr><th>ID</th><th>Date</th><th>Time</th><th>Patient</th><th>Doctor</th><th>Status</th></tr>
        <c:forEach var="a" items="${appointments}">
            <tr>
                <td>${a.appointmentId}</td>
                <td>${a.appointmentDate}</td>
                <td>${a.appointmentTime}</td>
                <td>${a.patientName}</td>
                <td>${a.doctorName}</td>
                <td>${a.status}</td>
            </tr>
            <th>
                <c:if test="${a.status == 'COMPLETED'}">
                    <a href="${pageContext.request.contextPath}/billing/view?appointmentId=${a.appointmentId}">View Bill</a>
                </c:if>
            </th>
        </c:forEach>
    </table>
</body>
</html>
