<%-- 
    Document   : doctor
    Created on : Sep 25, 2026, 9:29:55 PM
    Author     : ilham
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<!DOCTYPE html>
<html>
<head><title>Manage Doctors</title><link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">   <script src="${pageContext.request.contextPath}/js/app.js"></script></head>
<body>
    <h2>Manage Doctors</h2>
    <p><a href="${pageContext.request.contextPath}/admin/dashboard">Back to Dashboard</a> |
       <a href="${pageContext.request.contextPath}/admin/doctors/add">Add New Doctor</a></p>

    <table border="1" cellpadding="6">
        <tr><th>Name</th><th>Specialization</th><th>Fee (RM)</th><th>Available Days</th><th>Actions</th></tr>
        <c:forEach var="d" items="${doctors}">
            <tr>
                <td>${d.fullName}</td>
                <td>${d.specialization}</td>
                <td>RM ${d.consultationFee}</td>
                <td>${d.availableDays}</td>
                <td>
                    <a href="${pageContext.request.contextPath}/admin/doctors/edit?id=${d.doctorId}">Edit</a> |
                    <a href="${pageContext.request.contextPath}/admin/doctors/delete?id=${d.doctorId}"
                       onclick="return confirm('Delete Dr. ${d.fullName}? This also removes their login.');">Delete</a>
                </td>
            </tr>
        </c:forEach>
    </table>
</body>
</html>