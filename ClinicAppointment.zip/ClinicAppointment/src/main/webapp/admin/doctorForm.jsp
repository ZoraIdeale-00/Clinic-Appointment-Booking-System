<%-- 
    Document   : doctorForm
    Created on : Sep 25, 2026, 9:30:22 PM
    Author     : ilham
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<!DOCTYPE html>
<html>
<head><title>${mode == 'add' ? 'Add' : 'Edit'} Doctor</title><link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">   <script src="${pageContext.request.contextPath}/js/app.js"></script></head>
<body>
    <h2>${mode == 'add' ? 'Add New Doctor' : 'Edit Doctor'}</h2>
    <c:if test="${error != null}"><p style="color:red;">${error}</p></c:if>

    <c:choose>
        <c:when test="${mode == 'add'}">
            <form method="post" action="${pageContext.request.contextPath}/admin/doctors/add">
                <label>Username: <input type="text" name="username" required></label><br><br>
                <label>Password: <input type="password" name="password" required></label><br><br>
        </c:when>
        <c:otherwise>
            <form method="post" action="${pageContext.request.contextPath}/admin/doctors/edit">
                <input type="hidden" name="doctorId" value="${doctor.doctorId}">
                <input type="hidden" name="userId" value="${user.userId}">
        </c:otherwise>
    </c:choose>

        <label>Full Name: <input type="text" name="fullName" value="${user.fullName}" required></label><br><br>
        <label>Email: <input type="email" name="email" value="${user.email}" required></label><br><br>
        <label>Phone: <input type="text" name="phone" value="${user.phone}"></label><br><br>
        <label>Specialization: <input type="text" name="specialization" value="${doctor.specialization}" required></label><br><br>
        <label>Consultation Fee (RM): <input type="number" step="0.01" min="0" name="consultationFee" value="${doctor.consultationFee}" required></label><br><br>
        <label>Available Days: <input type="text" name="availableDays" placeholder="Mon,Wed,Fri" value="${doctor.availableDays}"></label><br><br>
        <button type="submit">${mode == 'add' ? 'Add Doctor' : 'Save Changes'}</button>
    </form>
    <p><a href="${pageContext.request.contextPath}/admin/doctors">Cancel</a></p>
</body>
</html>
